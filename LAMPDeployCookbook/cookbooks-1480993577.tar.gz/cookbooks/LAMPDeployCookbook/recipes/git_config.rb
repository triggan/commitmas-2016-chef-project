#
# Cookbook Name:: LAMPDeployCookbook
# Recipe:: gitConfig
#
# Copyright (c) 2016 The Authors, All Rights Reserved.


git_client 'default' do
  action :install
end
